# MyChart Pro — Version 1 prototype

## What's included
- Mobile-first dark chart workspace
- Market and timeframe selectors (1 minute through monthly)
- Candlestick chart using TradingView Lightweight Charts (Apache 2.0)
- Demo candles only (randomly generated; NOT live HFM data)
- Horizontal line, trendline and rectangle drawing
- Local drawing persistence in browser localStorage
- EMA 20 and SMA 50 overlays

## Run locally
Open `index.html` in a modern browser with an internet connection. The chart library is loaded from a CDN.

## Publish free with GitHub Pages
1. Create a new public GitHub repository named `mychart-pro`.
2. Upload `index.html` and `manifest.webmanifest` to the repository root.
3. Open repository Settings → Pages.
4. Under Build and deployment, choose Deploy from a branch, `main`, `/ (root)`, then Save.
5. Wait for GitHub Pages to publish, then open the URL on Android Chrome.
6. Chrome menu → Add to Home screen / Install app.

## Important limitations
This is a first prototype, not a complete TradingView clone.
- Prices are generated demo candles and are not real market data.
- No HFM connection is implemented.
- EMA/SMA are implemented; RSI, MACD, alerts, Gann, Fibonacci, PO3, sessions and other tools remain future work.
- Drawing tools are basic and should be tested before relying on them.
- For secure live broker data, use a backend; never put broker passwords or secret API keys in browser code.
